<?php
// Koneksi ke database
$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'diamond';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Fungsi untuk menampilkan tabel tertentu
function showTable($conn, $table_name, $columns) {
    echo "<h2>Data Tabel: $table_name</h2>";
    echo "<a href='$table_name.php?add=true' class='btn btn-add'>Tambah Data</a><br><br>";

    // Ambil data dari tabel
    $result = $conn->query("SELECT * FROM $table_name");

    if ($result->num_rows > 0) {
        echo "<table class='data-table'>";
        echo "<tr>";
        foreach ($columns as $col) {
            echo "<th>$col</th>";
        }
        echo "<th>Aksi</th></tr>";

        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            foreach ($columns as $col) {
                echo "<td>{$row[$col]}</td>";
            }
            echo "<td>
                    <a href='$table_name.php?edit=true&id={$row[$columns[0]]}' class='btn btn-edit'>Edit</a>
                    <a href='$table_name.php?delete=true&id={$row[$columns[0]]}' class='btn btn-delete'>Hapus</a>
                  </td>";
            echo "</tr>";
        }
        echo "</table><br><br>";
    } else {
        echo "<p class='no-data'>Tidak ada data di tabel $table_name.</p>";
    }
}

// Fungsi untuk menambahkan data
function addDataForm($table_name, $columns) {
    echo "<h2>Tambah Data ke Tabel: $table_name</h2>";
    echo "<form method='post' action='' class='form'>";
    foreach ($columns as $col) {
        if ($col != 'id') { // Skip ID jika auto increment
            echo "<label>$col:</label> <input type='text' name='$col' class='form-input'><br>";
        }
    }
    echo "<input type='submit' name='submit_add' value='Tambah Data' class='btn btn-submit'>";
    echo "</form>";
}

// Fungsi untuk edit data
function editDataForm($conn, $table_name, $columns, $id) {
    $id_col = $columns[0];
    $data = $conn->query("SELECT * FROM $table_name WHERE $id_col = $id")->fetch_assoc();

    echo "<h2>Edit Data Tabel: $table_name</h2>";
    echo "<form method='post' action='' class='form'>";
    foreach ($columns as $col) {
        echo "<label>$col:</label> <input type='text' name='$col' value='{$data[$col]}' class='form-input'><br>";
    }
    echo "<input type='hidden' name='id' value='$id'>";
    echo "<input type='submit' name='submit_edit' value='Update Data' class='btn btn-submit'>";
    echo "</form>";
}

// Array konfigurasi tabel
$tables = [
    'item_game' => ['id_item', 'nama_item', 'harga_diamond', 'deskripsi'],
    'pemain' => ['id_pemain', 'username', 'email', 'saldo', 'tanggal_daftar'],
    'pembelian_item' => ['id_pembelian', 'id_pemain', 'id_item', 'jumlah', 'tanggal_pembelian'],
    'saldo_pemain' => ['id_saldo', 'id_pemain', 'jumlah_perubahan', 'tanggal_perubahan'],
    'transaksi' => ['id_transaksi', 'id_pemain', 'total_diamond', 'metode_pembayaran', 'tanggal_transaksi', 'status']
];

// Logika utama CRUD per tabel
$table_name = basename(__FILE__, '.php');
if (!isset($tables[$table_name])) {
    die("Tabel tidak dikenali.");
}

$columns = $tables[$table_name];
if (isset($_GET['delete'])) {
    $id = $_GET['id'];
    $id_col = $columns[0];
    $conn->query("DELETE FROM $table_name WHERE $id_col = $id");
    header("Location: $table_name.php");
} elseif (isset($_GET['add'])) {
    addDataForm($table_name, $columns);
} elseif (isset($_GET['edit'])) {
    $id = $_GET['id'];
    editDataForm($conn, $table_name, $columns, $id);
} elseif (isset($_POST['submit_add'])) {
    $values = [];
    foreach ($columns as $col) {
        if ($col != 'id') {
            $values[] = "'" . $_POST[$col] . "'";
        }
    }
    $conn->query("INSERT INTO $table_name (" . implode(",", array_slice($columns, 1)) . ") VALUES (" . implode(",", $values) . ")");
    header("Location: $table_name.php");
} elseif (isset($_POST['submit_edit'])) {
    $id = $_POST['id'];
    $id_col = $columns[0];
    $updates = [];
    foreach ($columns as $col) {
        $updates[] = "$col = '" . $_POST[$col] . "'";
    }
    $conn->query("UPDATE $table_name SET " . implode(",", $updates) . " WHERE $id_col = $id");
    header("Location: $table_name.php");
} else {
    echo '<div style="display: flex; min-height: 100vh;">
    <!-- Navbar -->
    <div style="width: 200px; background-color: #111; color: #fff; padding: 20px;">
        <h3 style="color: #fff; text-align: center;">Menu</h3>
        <ul style="list-style: none; padding: 0;">
            <li><a href="pemain.php" style="color: #fff; text-decoration: none; display: block; padding: 10px; margin: 5px 0; background:rgb(25, 26, 26); border-radius: 4px;">Pemain</a></li>
            <li><a href="item_game.php" style="color: #fff; text-decoration: none; display: block; padding: 10px; margin: 5px 0; background: rgb(25, 26, 26); border-radius: 4px;">Item Game</a></li>
            <li><a href="transaksi.php" style="color: #fff; text-decoration: none; display: block; padding: 10px; margin: 5px 0; background: rgb(25, 26, 26); border-radius: 4px;">Transaksi</a></li>
            <li><a href="saldo_pemain.php" style="color: #fff; text-decoration: none; display: block; padding: 10px; margin: 5px 0; background: rgb(25, 26, 26); border-radius: 4px;">Saldo Pemain</a></li>
            <li><a href="pembelian_item.php" style="color: #fff; text-decoration: none; display: block; padding: 10px; margin: 5px 0; background:rgb(25, 26, 26); border-radius: 4px;">Pembelian Item</a></li>
        </ul>
    </div>
    <!-- Konten Utama -->
    <div style="flex: 1; padding: 20px;">';
    showTable($conn, $table_name, $columns);
    echo '    </div>
    </div>';
}

$conn->close();
?>

<style>
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f9;
    margin: 0;
    padding: 20px;
    color: #333;
}

h2 {
    color: #444;
    text-align: center;
}

.btn {
    display: inline-block;
    padding: 8px 15px;
    font-size: 14px;
    color: #fff;
    background-color: #007BFF;
    border: none;
    border-radius: 4px;
    text-decoration: none;
    cursor: pointer;
    margin: 5px 0;
}

.btn:hover {
    background-color: #0056b3;
}

.btn-edit {
    background-color: #ffc107;
}

.btn-edit:hover {
    background-color: #e0a800;
}

.btn-delete {
    background-color: #dc3545;
}

.btn-delete:hover {
    background-color: #bd2130;
}

.data-table {
    width: 100%;
    margin: 20px auto;
    border-collapse: collapse;
    background: #fff;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.data-table th, .data-table td {
    border: 1px solid #ddd;
    padding: 10px;
    text-align: left;
}

.data-table th {
    background-color: #f7f7f7;
}

.data-table tr:nth-child(even) {
    background-color: #f9f9f9;
}

.data-table tr:hover {
    background-color: #f1f1f1;
}

.no-data {
    text-align: center;
    font-size: 16px;
    color: #777;
}

.form {
    width: 60%;
    margin: 20px auto;
    padding: 20px;
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 4px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.form label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
}

.form-input {
    width: calc(100% - 20px);
    padding: 8px;
    margin-bottom: 10px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 14px;
}

.btn-submit {
    display: block;
    width: 100%;
    padding: 10px;
    font-size: 16px;
    background-color: #28a745;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

.btn-submit:hover {
    background-color: #218838;
}
</style>
