-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 19, 2024 at 04:52 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `diamond`
--

-- --------------------------------------------------------

--
-- Table structure for table `item_game`
--

CREATE TABLE `item_game` (
  `id_item` int(11) NOT NULL,
  `nama_item` varchar(100) NOT NULL,
  `harga_diamond` decimal(10,2) NOT NULL,
  `deskripsi` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `item_game`
--

INSERT INTO `item_game` (`id_item`, `nama_item`, `harga_diamond`, `deskripsi`) VALUES
(1, 'Diamond Sword', 50.00, 'A powerful sword for battle'),
(2, 'Healing Potion', 30.00, 'Restores health over time');

-- --------------------------------------------------------

--
-- Table structure for table `pemain`
--

CREATE TABLE `pemain` (
  `id_pemain` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `saldo` decimal(10,2) DEFAULT 0.00,
  `tanggal_daftar` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pemain`
--

INSERT INTO `pemain` (`id_pemain`, `username`, `email`, `saldo`, `tanggal_daftar`) VALUES
(1, 'player1', 'player1@example.com', 100.00, '2024-12-14 20:55:36'),
(2, 'player2', 'player2@example.com', 150.00, '2024-12-14 20:55:36');

-- --------------------------------------------------------

--
-- Table structure for table `pembelian_item`
--

CREATE TABLE `pembelian_item` (
  `id_pembelian` int(11) NOT NULL,
  `id_pemain` int(11) DEFAULT NULL,
  `id_item` int(11) DEFAULT NULL,
  `jumlah` int(11) NOT NULL,
  `tanggal_pembelian` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pembelian_item`
--

INSERT INTO `pembelian_item` (`id_pembelian`, `id_pemain`, `id_item`, `jumlah`, `tanggal_pembelian`) VALUES
(1, 1, 1, 1, '2024-12-14 20:55:36'),
(2, 2, 2, 2, '2024-12-14 20:55:36');

-- --------------------------------------------------------

--
-- Table structure for table `saldo_pemain`
--

CREATE TABLE `saldo_pemain` (
  `id_saldo` int(11) NOT NULL,
  `id_pemain` int(11) DEFAULT NULL,
  `jumlah_perubahan` decimal(10,2) NOT NULL,
  `tanggal_perubahan` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `saldo_pemain`
--

INSERT INTO `saldo_pemain` (`id_saldo`, `id_pemain`, `jumlah_perubahan`, `tanggal_perubahan`) VALUES
(1, 1, -50.00, '2024-12-14 20:55:36'),
(2, 2, -60.00, '2024-12-14 20:55:36');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` int(11) NOT NULL,
  `id_pemain` int(11) DEFAULT NULL,
  `total_diamond` decimal(10,2) NOT NULL,
  `metode_pembayaran` enum('cash','transfer','e-wallet') NOT NULL,
  `tanggal_transaksi` datetime DEFAULT current_timestamp(),
  `status` enum('pending','selesai','gagal') DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `id_pemain`, `total_diamond`, `metode_pembayaran`, `tanggal_transaksi`, `status`) VALUES
(1, 1, 100.00, 'e-wallet', '2024-12-14 20:55:36', 'selesai'),
(2, 2, 150.00, 'transfer', '2024-12-14 20:55:36', 'pending');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `item_game`
--
ALTER TABLE `item_game`
  ADD PRIMARY KEY (`id_item`);

--
-- Indexes for table `pemain`
--
ALTER TABLE `pemain`
  ADD PRIMARY KEY (`id_pemain`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `pembelian_item`
--
ALTER TABLE `pembelian_item`
  ADD PRIMARY KEY (`id_pembelian`),
  ADD KEY `id_pemain` (`id_pemain`),
  ADD KEY `id_item` (`id_item`);

--
-- Indexes for table `saldo_pemain`
--
ALTER TABLE `saldo_pemain`
  ADD PRIMARY KEY (`id_saldo`),
  ADD KEY `id_pemain` (`id_pemain`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `id_pemain` (`id_pemain`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `item_game`
--
ALTER TABLE `item_game`
  MODIFY `id_item` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pemain`
--
ALTER TABLE `pemain`
  MODIFY `id_pemain` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pembelian_item`
--
ALTER TABLE `pembelian_item`
  MODIFY `id_pembelian` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `saldo_pemain`
--
ALTER TABLE `saldo_pemain`
  MODIFY `id_saldo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `pembelian_item`
--
ALTER TABLE `pembelian_item`
  ADD CONSTRAINT `pembelian_item_ibfk_1` FOREIGN KEY (`id_pemain`) REFERENCES `pemain` (`id_pemain`),
  ADD CONSTRAINT `pembelian_item_ibfk_2` FOREIGN KEY (`id_item`) REFERENCES `item_game` (`id_item`);

--
-- Constraints for table `saldo_pemain`
--
ALTER TABLE `saldo_pemain`
  ADD CONSTRAINT `saldo_pemain_ibfk_1` FOREIGN KEY (`id_pemain`) REFERENCES `pemain` (`id_pemain`);

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`id_pemain`) REFERENCES `pemain` (`id_pemain`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
